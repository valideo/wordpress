﻿/*
Copyright (c) 2003-2014, CKSource - Frederico Knabben. All rights reserved.
For licensing, see LICENSE.md or http://ckeditor.com/license
*/
CKEDITOR.plugins.setLang( 'pastetext', 'tt', {
	button: 'Форматлаусыз текст өстәү',
	title: 'Форматлаусыз текст өстәү'
} );
